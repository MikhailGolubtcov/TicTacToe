﻿namespace EPAM.TicTacToe
{
    public class PlayerCellState
    {
        public enum playerCellState { X = 1, O = 2 };
    }
}
