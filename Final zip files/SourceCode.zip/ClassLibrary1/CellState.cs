﻿namespace EPAM.TicTacToe
{
    public class CellState
    {
        public enum cellState { Empty = 0, X = 1, O = 2 };
    }
}
