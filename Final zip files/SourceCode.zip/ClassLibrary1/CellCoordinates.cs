﻿namespace EPAM.TicTacToe
{
    public class CellCoordinates
    {
        public byte X { set; get; }
        public byte Y { set; get; }
    }
}
